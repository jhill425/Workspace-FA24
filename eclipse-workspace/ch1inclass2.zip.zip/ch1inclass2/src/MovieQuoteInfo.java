// Jennifer Hill 8/17/24 in class 2 ch1
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("In the end, there can be only one");
		System.out.println("Highlander");
		System.out.println("Conner MacLeod");
		System.out.println("1986");

	}

}
