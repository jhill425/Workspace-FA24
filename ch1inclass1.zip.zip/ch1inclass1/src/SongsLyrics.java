// Jennifer Hill 8/17/24 in class 1 ch1
public class SongsLyrics {

	public static void main(String[] args) {
		System.out.println("Shake it up is all that we know");
		System.out.println("Using the bodies up as we go");
		System.out.println("I'm waking up to fantasy");
		System.out.println("The shades all around");
		System.out.println("Aren't the colors we used to see");
	}

}
